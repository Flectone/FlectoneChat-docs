# anvil
`player-message.anvil`

Модуль anvil отвечает за форматирование названий предметов при переименовании в наковальне

![anvil](anvil.png)

```yaml
player-message:
  anvil:
    features: [swear-protection, patterns, formatting]
```

::: info features
Список возможностей, работающих при переименовании
:::
