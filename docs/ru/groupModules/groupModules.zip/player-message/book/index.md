# book
`player-message.book`

Модуль book отвечает за форматирование текста в книгах.

![book](book.png)

```yaml
player-message:
  book:
    features: [swear-protection, patterns, formatting]
```

::: info features
Список возможностей, работающих при редактировании книги
:::
