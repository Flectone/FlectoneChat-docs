# player-message
`player-message`

Категория player-message содержит в себе модули, отвечающие за сообщения игрока, причём не только в чате, а также на табличках, в книгах и в названиях предметов

## Модули
- [formatting](./formatting/)
- [patterns](./patterns/)
- [swear protection](./swear-protection/)
- [anvil](./anvil/)
- [sign](./sign/)
- [book](./book/)
- [chat](./chat/)