# player
`player`

Категория player включает в себя модули, отвечающие за действия связанные с игроком

## Модули
- [name](./name/)
- [name-tag](./name-tag/)
- [world](./world/)
- [afk-timeout](./afk-timeout/)
- [right-click](./right-click/)
- [hover](./hover/)
