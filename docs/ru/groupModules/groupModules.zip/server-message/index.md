# server-message
`server-message`

Категория server-message содержит в себе модули, отвечающие за сообщения, отправленные серверов (сообщения о смерти, получении достижения, заходе и выходе с сервера)

## Модули
- [death](./death/)
- [advancement](./advancement/)
- [join](./join/)
- [quit](./quit/)